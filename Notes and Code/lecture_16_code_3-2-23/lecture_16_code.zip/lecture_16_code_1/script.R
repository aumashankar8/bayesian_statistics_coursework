###
###  Read in Data for Binomial Model
###

mf.df=read.table("mosquitofish.txt",header=TRUE) # read in mosquitofish data
head(mf.df)

n=32 # those groups of fish that were only counted twice
y=mf.df$N1[1:n]
N=mf.df$N0[1:n]

plot(N,y,asp=TRUE)
abline(0,1)

###
###  Fit Binomial Model using 1 Chain
###

library(rjags)

m.jags <-"
  model{
    for(i in 1:n){
      y[i] ~ dbin(p,N[i])
    }
    p ~ dbeta(alpha,beta)
}
"

n.mcmc=1000
n.burn=round(.2*n.mcmc)
mod<-textConnection(m.jags) # read model
m.out<-jags.model(mod,data=list('y'=y,'n'=n,'N'=N,'alpha'=1,'beta'=1),n.chains=1,n.adapt=0) # build model graph 
m.samples=jags.samples(m.out,c('p'),n.mcmc) # fit model to data

plot(m.samples$p[1,,1],type="l",lty=1,ylab="p",xlab="iteration",ylim=c(0,1)) # trace plot

hist(m.samples$p[1,n.burn:n.mcmc,1],breaks=30,xlim=c(0,1),prob=TRUE,xlab="p",ylab="density",main="") # posterior histogram 
lines(density(m.samples$p[1,n.burn:n.mcmc,1]),lwd=2,col=2) 

###
###  Fit Binomial Model using 3 Chains and calculate R-hat by hand (Gelman et al., 2014; BDA3)
###

library(rjags)

m.jags <-"
  model{
    for(i in 1:n){
      y[i] ~ dbin(p,N[i])
    }
    p ~ dbeta(alpha,beta)
}
"

n.mcmc=10000
n.burn=round(.2*n.mcmc)
mod<-textConnection(m.jags) # read model
m.out<-jags.model(mod,data=list('y'=y,'n'=n,'N'=N,'alpha'=1,'beta'=1),n.chains=3,n.adapt=0) # build model graph 
m.samples=jags.samples(m.out,c('p'),n.mcmc) # fit model to data

#m.samples$p[1,,1]=rbeta(n.mcmc,8,2)

matplot(m.samples$p[1,,],type="l",col=1:3,lty=1,ylab="p",xlab="iteration",ylim=c(0,1)) # trace plots

keep.idx=n.burn:n.mcmc # discard burn-in
K=length(keep.idx)
w=mean(apply(m.samples$p[1,keep.idx,],2,var))
b=K*var(apply(m.samples$p[1,keep.idx,],2,mean))
v.hat=w*(K-1)/K+b/K
r.hat=sqrt(v.hat/w)
r.hat

###
###  Fit Binomial Model using 3 Chains and use CODA to calculate R-hat (using different formulation) 
###

library(rjags)
library(coda)

m.jags <-"
  model{
    for(i in 1:n){
      y[i] ~ dbin(p,N[i])
    }
    p ~ dbeta(alpha,beta)
}
"

n.mcmc=100
n.burn=round(.2*n.mcmc)
mod<-textConnection(m.jags) # read model
m.out<-jags.model(mod,data=list('y'=y,'n'=n,'N'=N,'alpha'=1,'beta'=1),n.chains=3,n.adapt=0) # build model graph 
m.samples=coda.samples(m.out,c('p'),n.mcmc) # fit model to data

gelman.diag(m.samples)

###
###  Simulate Data for Hierarchical Binomial Model
###

n=10
lambda=20
N=rpois(n,lambda)
p=.8
y=rbinom(n,N,p)

plot(N,y,xlim=c(0,max(N)),ylim=c(0,max(N)))
abline(0,1)

###
###  Fit Hierarchical Binomial-Poisson Model assuming p and all N Unknown (but lambda known)
###



